/*
 * ADC.h
 *
 *  Created on: Nov 27, 2025
 *      Author: marth
 */

#ifndef INC_ADC_H_
#define INC_ADC_H_


#include "main.h"
#include "adc_custom.h"

extern ADC_HandleTypeDef hadc1;

// Definiciones públicas
#define N_MED 10
#define NUM_SENSORS 4

// Canales ADC para cada sensor
extern const uint32_t sensor_channels[NUM_SENSORS];

// Variables públicas para las lecturas de distancia


// Prototipos de funciones públicas
void sensor_init(void);
float mediradc();
float filtro(float med);
float distanciaS1(int sens);
float distanciaS2(int sens);
float distanciaS3(int sens);
float distanciaS4(int sens);
int leerADCoff(int sensor_index);
int leerADCon(int sensor_index);

#endif /* INC_ADC_H_ */
