/*
 * trapezoidal.h
 *
 *  Created on: Oct 30, 2025
 *      Author: marth
 */

#ifndef INC_TRAPEZOIDAL_H_
#define INC_TRAPEZOIDAL_H_
#include <stdint.h>
#include <stdbool.h>
#include "Odometria.h"

typedef struct {
   int32_t velmax;
   int32_t acc;
   int32_t dist;
} PERFIL;

float trapecio(PERFIL *p1, float tiempotranscurrido, Pose *plocal);
void resettr(PERFIL *p1);

#endif /* INC_TRAPEZOIDAL_H_ */
