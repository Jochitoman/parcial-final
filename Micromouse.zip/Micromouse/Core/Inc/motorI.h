#ifndef MOTOR_I_H_
#define MOTOR_I_H_

#include "stm32f4xx_hal.h"

void MotorI_SetSpeed(float vel);

#endif
