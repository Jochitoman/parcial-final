/*
 * PID.h
 *
 *  Created on: Nov 5, 2025
 *      Author: marth
 */

#ifndef INC_PID_H_
#define INC_PID_H_

typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float T;           // tiempo de muestreo (s)
    float prev_error;  // error anterior
    float integral;    // suma de errores
    float out_min;     // límite inferior
    float out_max;     // límite superior
} PID;

void PID_Init(PID *pid, float Kp, float Ki, float Kd, float T);
float PIDfin(PID *pid, float setpoint, float measurement);

#endif /* INC_PID_H_ */

