#ifndef VOLTAJE_H_
#define VOLTAJE_H_

#include "stm32f4xx_hal.h"

// Inicialización opcional (si ya configuras TIM3 y GPIOs en el main, puede quedar vacía)
void Voltaje_Init(void);

// Ajusta el PWM y la dirección de los motores a partir de un voltaje dado
// volta: voltaje en volts, rango sugerido -7.5V a +7.5V
void Voltaje_Set(float volta);

#endif /* VOLTAJE_H_ */
