/*
 * Andar.h
 *
 *  Created on: Nov 10, 2025
 *      Author: Juan
 */

#ifndef INC_ANDAR_H_
#define INC_ANDAR_H_

#include "Odometria.h"
#include "trapezoidal.h"
#include "PID.h"
#include "motorD.h"
#include "motorI.h"
#include <stdint.h>

void Andar(PERFIL *perfil, Pose *pose, PID *pidi, PID *pidd, float dt);

#endif /* INC_ANDAR_H_ */
