/*
 * Odometría.h
 *
 *  Created on: Oct 21, 2025
 *      Author: jdjh0
 */


#ifndef INC_POSE_H_
#define INC_POSE_H_

#include "main.h"
#include <math.h>

#define WHEEL_RADIUS_MM         16.75   // Radio de la rueda (ajusta)
#define WHEEL_BASE_MM           80.0   // Distancia entre ruedas
#define PULSES_PER_REVOLUTION   1433.0f  // Pulsos por vuelta del encoder
#define PI_PROPIO               3.14159265359f

typedef struct {
    float x;
    float y;
    float theta;
    float velMotorL;
    float velMotorR;
    float velLineal;
    float velAngular;
    float avanceLineal;
    float left_distance_mm;
    float right_distance_mm;
    float left_distance_mm_acum;
    float right_distance_mm_acum;
} Pose;

void updatePose(Pose *pose, int16_t left_pulses, int32_t right_pulses, float delta_time_ms);
void resetodo(Pose *pose);
#endif /* INC_POSE_H_ */
