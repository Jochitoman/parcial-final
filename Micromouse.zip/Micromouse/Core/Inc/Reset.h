/*
 * Reset.h
 *
 *  Created on: Nov 5, 2025
 *      Author: marth
 */

#ifndef INC_RESET_H_
#define INC_RESET_H_


#include "Odometria.h"
#include "trapezoidal.h"
#include "motorD.h"
#include "motorI.h"

// Prototipo general
void Reset(void);


#endif /* INC_RESET_H_ */
