/*
 * trapezoidala.h
 *
 *  Created on: Nov 10, 2025
 *      Author: marth
 */

#ifndef INC_TRAPEZOIDALA_H_
#define INC_TRAPEZOIDALA_H_


#include <stdint.h>
#include <stdbool.h>
#include "Odometria.h"

typedef struct {
   float velmax;
   float acc;
   float dist;
   float giro;
} PERFILA;

float trapecioa(PERFILA *p1, float tiempotranscurrido, Pose *plocal);
void resettra(PERFILA *p1);



#endif /* INC_TRAPEZOIDALA_H_ */
