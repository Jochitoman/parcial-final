#ifndef MOTOR_D_H_
#define MOTOR_D_H_

#include "stm32f4xx_hal.h"  // Cambia según tu MCU

void MotorD_Init(void);
void MotorD_SetSpeed(float vel);

#endif /* MOTOR_D_H_ */
