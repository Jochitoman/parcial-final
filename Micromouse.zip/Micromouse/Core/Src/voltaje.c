#include "voltaje.h"
#include <math.h>  // para fabsf()

extern TIM_HandleTypeDef htim3;  // Usa el TIM3 configurado en el main

void Voltaje_Init(void)
{
    // Si ya tienes configurado PWM y GPIOs en el main, esto puede quedar vacío.
}

void Voltaje_Set(float volta)
{
    // Calcula el valor proporcional del PWM basado en el voltaje recibido
    float valor_loc = ((fabsf(volta) * 3200.0f) / 7.5f);
    int valor_ent = (int)valor_loc;

    if (volta < 0)
    {
        // Sentido hacia adelante
        TIM3->CCR1 = valor_ent;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);

        TIM3->CCR2 = valor_ent;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
    }
    else if (volta > 0)
    {
        // Sentido inverso
        TIM3->CCR1 = valor_ent;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);

        TIM3->CCR2 = valor_ent;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
    }
    else
    {
        // Voltaje = 0 → detener motores
        TIM3->CCR1 = 0;
        TIM3->CCR2 = 0;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
    }
}
