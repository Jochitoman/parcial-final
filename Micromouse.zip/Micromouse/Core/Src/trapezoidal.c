/*
 * trapezoidal.c
 *
 *  Created on: Oct 30, 2025
 *      Author: marth
 */
#include "trapezoidal.h"
#include <math.h>
#include "Odometria.h"

extern uint8_t calcular;
extern volatile uint8_t final;
uint8_t bandera = 0;

float trapecio(PERFIL *p1, float tiempotranscurrido, Pose *plocal){

	static float vel;
	float Dfren=((plocal->velLineal)*(plocal->velLineal))/(2.0*p1->acc);
	float Dfalt= p1->dist - (vel*tiempotranscurrido);

	if (bandera == 0){
		if (vel < (float)p1->velmax){
			//final=0;
			vel = (float)p1->acc * tiempotranscurrido;
		} else {
			vel = (float)p1->velmax;
		}
	}

	if ((Dfren >= Dfalt)||bandera==1){
		bandera = 1;
		vel = vel - ((float)p1->acc * 0.01);
		if(vel<40.0)vel=40.0;
	}

	if (plocal->avanceLineal >= (float)p1->dist){
		vel = 0;
		p1->acc = 0;
		p1->dist = 0;
		p1->velmax = 0;
		//resetodo(plocal);
		bandera=0;
		//final=1;
	}
	return vel;
}

void resettr(PERFIL *p1){
	p1->acc=0;
	p1->dist=0;
	p1->velmax=0;
}


