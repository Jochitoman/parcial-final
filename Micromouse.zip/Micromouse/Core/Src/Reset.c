/*
 * Reset.c
 *
 *  Created on: Nov 5, 2025
 *      Author: marth
 */

#include "reset.h"
#include <string.h>

// Variables externas declaradas en otros módulos
extern Pose robotPose;
extern PERFIL perfil;
void Reset(void)
{
    memset(&robotPose, 0, sizeof(Pose));
    memset(&perfil, 0, sizeof(PERFIL));
    // Aquí puedes agregar más resets (PID, sensores, flags, etc.)
}


