#include "motorD.h"
extern TIM_HandleTypeDef htim3;


void MotorD_SetSpeed(float vel) {
    float calculo, valor_loc;
    int valor_ent;

    if (vel > 0) {
        calculo = ((vel + 19.26) / 85.808);
        valor_loc = ((calculo * 3200.0) / 7.5);
        valor_ent = (int)valor_loc;

        TIM3->CCR1 = valor_ent;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
    } else {
        float yneg = -vel;
        calculo = ((yneg + 19.26) / 85.808);
        valor_loc = ((calculo * 3200.0) / 7.5);
        valor_ent = (int)valor_loc;

        TIM3->CCR1 = valor_ent;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
    }
}
