/*
 * Andar.c
 *
 *  Created on: Nov 10, 2025
 *      Author: Juan
 */

#include "andar.h"
#include "usb_device.h"
#include <usbd_cdc_if.h>
#include <stdio.h>
#include <math.h>

extern uint8_t calcular;  // bandera global

void Andar(PERFIL *perfil, Pose *pose, PID *pidi, PID *pidd, float tiempotranscurrido)
{
    static uint8_t primeravez = 0;
    static float tiempo = 0.0f;   // ajuste motor físico
    //char texto[128];

    if (!calcular)
        return;

    if (!primeravez)
    {
        primeravez = 1;
        tiempotranscurrido = 0.0f;
    }

  tiempo = tiempotranscurrido + 0.01;

    // 1️⃣ Calcular velocidad deseada del perfil trapezoidal
    float veldeseada = trapecio(perfil, tiempo, pose);

    if (veldeseada == 0)
    {
        MotorI_SetSpeed(0);
        MotorD_SetSpeed(0);
        calcular = 0;
        primeravez = 0;
        return;
    }

    // 2️⃣ Control PID por rueda
    float velfini = PIDfin(pidi, veldeseada, pose->velMotorL);
    float velfind = PIDfin(pidd, veldeseada, pose->velMotorR);

    float velctrli = (velfini + veldeseada);
    float velctrld = (velfind + veldeseada);

    // 3️⃣ Saturación de seguridad
    if (velctrli > 629) velctrli = 629;
    else if (velctrli < -629) velctrli = -629;

    if (velctrld > 629) velctrld = 629;
    else if (velctrld < -629) velctrld = -629;

    // 4️⃣ Aplicar velocidades a los motores
    MotorI_SetSpeed(velctrli);
    MotorD_SetSpeed(velctrld);

    /* 5️⃣ (opcional) Enviar datos por USB
    sprintf(texto, ">vd:%.2f >vl:%.2f >vdese:%.2f\r\n",
            pose->velMotorR, pose->velMotorL, veldeseada);
    CDC_Transmit_FS((uint8_t *)texto, strlen(texto));*/
}
