/*
 * ADC.c
 *
 *  Created on: Nov 27, 2025
 *      Author: marth
 */

#include "ADC.h"

// Variables privadas del módulo
static uint32_t off_vals[NUM_SENSORS];
static uint32_t on_vals[NUM_SENSORS];
static uint32_t delta[NUM_SENSORS] = {0};
static uint32_t media[NUM_SENSORS] = {0};
static int contador = 0;
volatile float lectura = 0;
volatile float med1 = 0;

// Canales ADC (ajusta según tu configuración)
const uint32_t sensor_channels[NUM_SENSORS] = {
    ADC_CHANNEL_4,
    ADC_CHANNEL_6,
    ADC_CHANNEL_5,
    ADC_CHANNEL_7
};

// Tablas de calibración (privadas)
static float medidas[18] = {5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90};
static float sensor1[18] = {153,127,94,74,64,50,43,37,30,24,19,17,15,13,12,10,8,7};
static float sensor2[11] = {59,53,32,23,19,14,11,10,8,7,6};
static float sensor3[16] = {182,142,94,73,59,50,40,34,29,23,19,17,16,14,12,9};
static float sensor4[14] = {77,64,42,33,27,22,18,16,14,11,10,9,8,7};

void sensor_init(void)
{
    // Inicialización del módulo de sensores
    // (Puedes agregar aquí código de inicialización si es necesario)
    contador = 0;
    for(int i = 0; i < NUM_SENSORS; i++) {
        delta[i] = 0;
        media[i] = 0;
    }
}

float mediradc()
{
    // Realizar barrido OFF/ON para los 4 sensores
	for (int k = 0; k < 4; k++)
	          {
	              // --- Leer OFF (todos los LEDs apagados)
	              // Aseguramos que estén apagados
	              HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_10, GPIO_PIN_RESET);
	              off_vals[k] = (uint32_t) ADC_SelectCH(&hadc1, sensor_channels[k]);

	              // --- Encender LED k
	              if (k == 0) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
	              else if (k == 1) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
	              else if (k == 2) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
	              else if (k == 3) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_SET);
	              // pequeña espera para estabilizar la lectura (ajusta si requieres más rapidez)

	              // --- Leer ON (LED encendido)
	              on_vals[k] = (uint32_t) ADC_SelectCH(&hadc1, sensor_channels[k]);

	              // --- Apagar LED k nuevamente
	              if (k == 0) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
	              else if (k == 1) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
	              else if (k == 2) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
	              else if (k == 3) HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_RESET);

	          }
	      // Calcular promedios y delta por sensor
	      /*for (int i = 0; i < 4; i++)
	      {
	    	  delta[i] = delta[i]+(on_vals[i] - off_vals[i]);
	    	  //med1=delta[0];

	      }

	      contador++;
	      if (contador == 5){
	    	  contador=0;
	    	  for (int j = 0; j<4; j++){
	    		  media[j] = (delta[j]/5);
	    		  delta[j]=0;
	    		  med1=media[0];
	    		  //med2=media[1];
	    		  //med3=media[2];
	    		  //med4=media[3];
	    	  }
	      }*/
	med1=on_vals[0];
	int32_t filt = distanciaS1(med1);
		  lectura=filtro(filt);
		  //lectura2=distanciaS2(med2);
		  //lectura3=distanciaS3(med3);
		  //lectura4=distanciaS4(med4);
    return lectura;

}

float filtro(float med)
{
    static float y_prev = 0;
    float alpha = 0.3;
    float y_filtrado = y_prev + alpha * (med - y_prev);
    y_prev = y_filtrado;
    return y_filtrado;
}

float distanciaS1(int sens)
{
    float mm = 0;
    for (int f = 0; f < 17; f++) {
        if(sensor1[f] > sens && sens > sensor1[f+1]) {
            float x1 = sensor1[f];
            float x2 = sensor1[f+1];
            float y1 = medidas[f];
            float y2 = medidas[f+1];
            mm = y1 + ((sens - x1) * (y2 - y1)) / (x2 - x1);
            return mm;
        }
    }
    if(sens <= sensor1[17]) {
        return 90.0;
    } else {

    	return 2.0;
    }
}

float distanciaS2(int sens)
{
    for (int f = 0; f < 10; f++) {
        if(sensor2[f] > sens && sens > sensor2[f+1]) {
            float x1 = sensor2[f];
            float x2 = sensor2[f+1];
            float y1 = medidas[f];
            float y2 = medidas[f+1];
            float mm = y1 + ((sens - x1) * (y2 - y1)) / (x2 - x1);
            return mm;
        }
    }
    if(sens <= sensor2[10]) {
        return 90.0;
    } else {
        return 2.0;
    }
}

float distanciaS3(int sens)
{
    for (int f = 0; f < 15; f++) {
        if(sensor3[f] > sens && sens > sensor3[f+1]) {
            float x1 = sensor3[f];
            float x2 = sensor3[f+1];
            float y1 = medidas[f];
            float y2 = medidas[f+1];
            float mm = y1 + ((sens - x1) * (y2 - y1)) / (x2 - x1);
            return mm;
        }
    }
    if(sens <= sensor3[15]) {
        return 90.0;
    } else {
        return 2.0;
    }
}

float distanciaS4(int sens)
{
    for (int f = 0; f < 13; f++) {
        if(sensor4[f] > sens && sens > sensor4[f+1]) {
            float x1 = sensor4[f];
            float x2 = sensor4[f+1];
            float y1 = medidas[f];
            float y2 = medidas[f+1];
            float mm = y1 + ((sens - x1) * (y2 - y1)) / (x2 - x1);
            return mm;
        }
    }
    if(sens <= sensor4[13]) {
        return 90.0;
    } else {
        return 2.0;
    }
}

int leerADCoff(int sensor_index)
{
    if (sensor_index < 1 || sensor_index > NUM_SENSORS) return 0;
    uint32_t val = ADC_SelectCH(&hadc1, sensor_channels[sensor_index - 1]);
    return (int)val;
}

int leerADCon(int sensor_index)
{
    if (sensor_index < 1 || sensor_index > NUM_SENSORS) return 0;
    uint32_t val = ADC_SelectCH(&hadc1, sensor_channels[sensor_index - 1]);
    return (int)val;
}
