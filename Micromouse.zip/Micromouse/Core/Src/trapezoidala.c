/*
 * trapezoidala.c
 *
 *  Created on: Nov 10, 2025
 *      Author: marth
 */


#include "trapezoidala.h"
#include <math.h>
#include "Odometria.h"

extern uint8_t calcular;
uint8_t bandera1 = 0;
uint8_t der = 0;
uint8_t izq = 0;
float trapecioa(PERFILA *p1, float tiempotranscurrido, Pose *plocal){
	if(p1->giro==0){
		if (p1->dist>0){
			der=0;
			izq=1;
			p1->giro=1;
		}else{
			der=1;
			izq=0;
			p1->giro=1;
		}
	}

	if (izq==1){
	float arco = 40.0 * p1->dist;
	static float vel;
		float Dfren=((plocal->velAngular)*(plocal->velAngular))/(2.0*p1->acc);
		float Dfalt= arco - (vel*tiempotranscurrido);

		if (bandera1 == 0){
			if (vel < (float)p1->velmax){
				vel = (float)p1->acc * tiempotranscurrido;
			} else {
				vel = (float)p1->velmax;
			}
		}

		if ((Dfren >= Dfalt)||bandera1==1){
			bandera1 = 1;
			vel = vel - ((float)p1->acc * 0.01);
			if(vel<40.0)vel=40.0;
		}

		if (plocal->right_distance_mm_acum >= arco){
			vel = 0;
			p1->acc = 0;
			p1->dist = 0;
			p1->velmax = 0;
			bandera1=0;
		}
		return vel;
	}
	if (der==1){
		float arco = 40.0 * p1->dist * -1;
		static float vel;
			float Dfren=((plocal->velAngular)*(plocal->velAngular))/(2.0*p1->acc);
			float Dfalt= arco - (vel*tiempotranscurrido);

			if (bandera1 == 0){
				if (vel < (float)p1->velmax){
					vel = (float)p1->acc * tiempotranscurrido;
				} else {
					vel = (float)p1->velmax;
				}
			}

			if ((Dfren >= Dfalt)||bandera1==1){
				bandera1 = 1;
				vel = vel - ((float)p1->acc * 0.01);
				if(vel<40.0)vel=40.0;
			}

			if (plocal->left_distance_mm_acum >= arco){
				vel = 0;
				p1->acc = 0;
				p1->dist = 0;
				p1->velmax = 0;
				bandera1=0;
			}
			return vel;

	}
}
void resettra(PERFILA *p1){
	p1->acc=0;
	p1->dist=0;
	p1->velmax=0;
}
