/*
 * Odometría.c
 *
 *  Created on: Oct 21, 2025
 *      Author: jdjh0
 */

#include <Odometria.h>

void updatePose(Pose *pose, int16_t left_pulses, int32_t right_pulses, float delta_time_ms)
{
    // --- Convertir tiempo a segundos ---
    float delta_time_s = delta_time_ms;
    static const float stop_threshold = 5.0f; // mm/s (umbral de parada opcional)

    // --- Distancia recorrida por cada rueda (en mm) ---
    pose->left_distance_mm  = (2.0f * PI_PROPIO * WHEEL_RADIUS_MM * (float)left_pulses) / PULSES_PER_REVOLUTION;
    pose->right_distance_mm = (2.0f * PI_PROPIO * WHEEL_RADIUS_MM * (float)right_pulses) / PULSES_PER_REVOLUTION;

    // --- Acumulado total ---
    pose->left_distance_mm_acum  += pose->left_distance_mm;
    pose->right_distance_mm_acum += pose->right_distance_mm;

    // --- Promedio del desplazamiento lineal ---
    float delta_lineal = (pose->left_distance_mm + pose->right_distance_mm) / 2.0f;
    pose->avanceLineal += (delta_lineal);

    // --- Velocidades individuales y lineal ---
    pose->velMotorL = pose->left_distance_mm / delta_time_s;
    pose->velMotorR = pose->right_distance_mm / delta_time_s;
    pose->velLineal = delta_lineal / delta_time_s;

    // --- Cambio en orientación ---
    float delta_angular = (pose->right_distance_mm - pose->left_distance_mm) / WHEEL_BASE_MM;
    pose->velAngular = delta_angular / delta_time_s;

    // --- Actualización del ángulo ---
    pose->theta += delta_angular;

    // Mantener theta entre [-π, π]
    if (pose->theta > PI_PROPIO)
        pose->theta -= 2.0f * PI_PROPIO;
    else if (pose->theta < -PI_PROPIO)
        pose->theta += 2.0f * PI_PROPIO;

    // --- Actualización de la posición (x, y) ---
    pose->x += delta_lineal * cosf(pose->theta);
    pose->y += delta_lineal * sinf(pose->theta);
}

void resetodo (Pose *pose){
	pose->avanceLineal=0;
	pose->left_distance_mm=0;
	pose->left_distance_mm_acum=0;
	pose->right_distance_mm=0;
	pose->right_distance_mm_acum=0;
	pose->theta=0;
	pose->velAngular=0;
	pose->velLineal=0;
	pose->velMotorL=0;
	pose->velMotorR=0;
	pose->x=0;
	pose->y=0;
}

