/*
 * PID.c
 *
 *  Created on: Nov 5, 2025
 *      Author: marth
 */


#include "PID.h"

void PID_Init(PID *pid, float Kp, float Ki, float Kd, float T)
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->T  = T;

    pid->prev_error = 0.0f;
    pid->integral = 0.0f;

    pid->out_min = -600.0f;
    pid->out_max =  600.0f;
}

float PIDfin(PID *pid, float setpoint, float measurement)
{
    // calcular error
    float error = setpoint - measurement;

    // integrar error
    pid->integral += error * pid->T;

    // derivada del error
    float derivative = (error - pid->prev_error) / pid->T;

    // salida PID
    float output = pid->Kp * error + pid->Ki * pid->integral + pid->Kd * derivative;

    // saturación
    if (output > pid->out_max) output = pid->out_max;
    else if (output < pid->out_min) output = pid->out_min;

    pid->prev_error = error;

    return output;
}

