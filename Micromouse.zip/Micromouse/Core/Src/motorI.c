#include "motorI.h"
extern TIM_HandleTypeDef htim3;


void MotorI_SetSpeed(float vel) {
    float calculo, valor_loc;
    int valor_ent;

    if (vel > 0) {
    	//((vel + 23.749) / 89.348);
        calculo = ((vel + 23.749) / 89.348);
        valor_loc = ((calculo * 3200.0) / 7.5);
        valor_ent = (int)valor_loc;

        TIM3->CCR2 = valor_ent;

        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
    } else {
        float yneg = -vel;
        calculo = ((yneg + 23.749) / 89.348);
        valor_loc = ((calculo * 3200.0) / 7.5);
        valor_ent = (int)valor_loc;

        TIM3->CCR2 = valor_ent;

        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

    }
}


